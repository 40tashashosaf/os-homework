#include <stdio.h>
#include <stdlib.h>
int main(){
int n=100;
int zero=0;
int *data;
data=(int*)malloc(n*sizeof(int));
free(data[50]);
return 0;
}
