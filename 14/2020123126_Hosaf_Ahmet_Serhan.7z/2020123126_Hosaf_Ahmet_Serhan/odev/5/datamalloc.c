#include <stdio.h>
#include <stdlib.h>
int main(){
int n=100;
int zero=2;
int *data;
data=(int*)malloc(n*sizeof(int));
data[100]=zero;
return 0;
}
