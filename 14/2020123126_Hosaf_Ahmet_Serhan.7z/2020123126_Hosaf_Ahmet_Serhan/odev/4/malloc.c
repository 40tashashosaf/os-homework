#include <stdio.h>
#include <stdlib.h>
int main(){
int n=100;
int *mypointer;
mypointer=malloc(n*sizeof(int));
return 0;
}
