#include <stdio.h>
#include <stdlib.h>
int main(){
int n=100;
int zero=0;
int *data;
data=(int*)malloc(n*sizeof(int));
data[0]=zero;
free(data);
printf("%d",data[0]);
return 0;
}
