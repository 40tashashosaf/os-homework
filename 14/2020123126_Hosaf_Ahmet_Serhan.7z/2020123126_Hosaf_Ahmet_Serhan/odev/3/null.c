#include <stdio.h>
int main(){
int* mypointer=NULL;
int x=*mypointer; 
return 0;
}
